

Authors
==========


Core Development Team
---------------------

- Maximilian Christ (`maximilianchrist.com <http://maximilianchrist.com>`_, `max.christ@me.com <max.christ@me.com>`_)
- Nils Braun  (`nilslennartbraun@gmail.com <nilslennartbraun@gmail.com>`_)
- Julius Neuffer (`julius.neuffer@blue-yonder.com <julius.neuffer@blue-yonder.com>`_)
- Andreas W. Kempa-Liehr (`a.kempa-liehr@auckland.ac.nz <https://unidirectory.auckland.ac.nz/profile/akem134>`_)

Contributions
-------------

- Alan Larson
- Alex Broekhof
- Alex F
- Alex Kennedy
- Alex Loosley
- Andrew Van Benschoten
- Ben Auffarth
- Brian Sang
- Brunno Vanelli
- Chris Chow
- Chris Holdgraf
- Christoph Hösler
- cnzero
- CYHSM
- Dan Mazur
- Daniel Azevedo
- Daniel Gomez
- Daniel Naftalovich
- Delyan
- Denis Barbier
- Derrick
- Dhruv Srikanth
- Dillon Wong
- Dimitris Spathis
- Dominic White
- earthgecko
- Emanuele Fumagalli
- Erlend Aune
- Evans Doe Ocansey
- Ezekiel Kruglick
- Filip Malkowski
- filipj8
- Florian Aspart
- flyingdutchman23
- Fujimoto Seiji
- George Wambold
- Greg Bodeker
- Gregor Koehler
- Gustavo Bertoli
- Haris Sahovic
- HaveF
- He Kaisheng
- Henry Swaffield
- J. Kleint
- James Myatt
- Jean-Francois Zinque
- Jeroen Van Der Donckt
- Justin Hong
- Justin White
- kartikey-vyas
- koho
- Lifepillar
- lupupu
- Mal Curtis
- Mario Kahlhofer
- Markus Frey
- Marx
- Matúš Tomlein
- Maximilian Lohmann
- meer1992
- mendel5
- Michele Tonutti
- Moritz Gelb
- Nigel Bosch
- Niklas Haas
- Oli
- Omar Gutiérre
- patrjon
- Paul Fornia
- Paul Voigt
- Quan Gu
- rhysimu
- Ricardo Emanuel Vaz Vargas
- Roman Yurchak
- Roy Wedge
- Sarius2009
- Sean M. Law
- Sergey Shepelev
- Soledad Galli
- Stephan Müller
- supergitacc
- Tan Tao-Lin
- Teo Bucci
- Thibault Blanc
- Thibault de Boissiere
- Timo Klerx
- Vincent Tang
- Will Koehrsen
- Wojciech Indyk
- yairst
- YamaByte
- yitao-yu
