DATETIME_TYPES = ("datetimetz", "datetime")
