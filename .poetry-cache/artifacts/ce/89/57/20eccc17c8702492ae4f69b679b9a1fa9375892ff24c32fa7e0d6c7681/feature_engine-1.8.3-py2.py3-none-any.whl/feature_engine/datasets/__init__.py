from .titanic import load_titanic

__all__ = ["load_titanic"]
