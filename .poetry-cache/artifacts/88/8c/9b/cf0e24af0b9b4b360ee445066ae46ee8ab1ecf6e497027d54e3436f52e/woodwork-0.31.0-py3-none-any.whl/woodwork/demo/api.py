# flake8: noqa
from woodwork.demo.retail import load_retail
