from featuretools.primitives.standard.transform.email.email_address_to_domain import (
    EmailAddressToDomain,
)
from featuretools.primitives.standard.transform.email.is_free_email_domain import (
    IsFreeEmailDomain,
)
