# flake8: noqa
from featuretools.demo.flight import load_flight
from featuretools.demo.mock_customer import load_mock_customer
from featuretools.demo.retail import load_retail
from featuretools.demo.weather import load_weather
