# flake8: noqa
from featuretools.synthesis.deep_feature_synthesis import DeepFeatureSynthesis
from featuretools.synthesis.dfs import dfs
from featuretools.synthesis.encode_features import encode_features
from featuretools.synthesis.get_valid_primitives import get_valid_primitives
