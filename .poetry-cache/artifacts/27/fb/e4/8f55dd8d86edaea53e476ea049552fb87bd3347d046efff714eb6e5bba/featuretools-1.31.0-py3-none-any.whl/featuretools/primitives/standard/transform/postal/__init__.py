from featuretools.primitives.standard.transform.postal.one_digit_postal_code import (
    OneDigitPostalCode,
)
from featuretools.primitives.standard.transform.postal.two_digit_postal_code import (
    TwoDigitPostalCode,
)
