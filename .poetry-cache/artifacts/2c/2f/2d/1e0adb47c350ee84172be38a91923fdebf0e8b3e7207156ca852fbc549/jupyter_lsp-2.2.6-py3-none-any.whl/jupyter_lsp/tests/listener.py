async def dummy_listener(scope, message, language_server, manager):
    pass
